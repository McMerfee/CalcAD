# ADS Webapp

ADS Webapp contains configurator, auth, constructor of orders, generation of specs and processing of orders

## Running project

1. Clone repository
2. Install dependencies
```sh
npm install
```
3. To run project locally for development
```sh
npm run dev
```
4. Ask permission for the .env/config.js file with environment variables sheet and Api Keys

You are all settled! Seeds get populated on first app start in case DB is empty!

## Deployment

We are using [Heroku](https://heroku.com/) for all the deployments.
1. Request access to our heroku app
2. You can deploy to the [Staging](https://ads-calc-stage.herokuapp.com/) by pushing to heroku by:
```sh
git remote add heroku https://git.heroku.com/ads-calc-stage.git
git push heroku master
```
3. Heroku git URL [Production]: https://git.heroku.com/ads-calc.git


## Commit strategy

We're working with [GitFlow](https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow) strategy
So make sure you rebase your branch against `develop` and name it in a correct way according to the kind of work that you currently planning to work with.

“hotfix” branch has been forked directly off of master. So please use this branch to quickly patch production releases. Than it should be merged into both master and develop branches.

Once task is completed you should:
- make sure you don't leave any redundant commented-out code
- make a `git pull` from develop branch and merge conflicts in case any occur
- push your code and make a pull-request to `develop` branch
- put at least two reviewers from your team(if it is possible) to your PR

You should check your open pull-requests at least once a day and notify reviewers to check it if that's left uncomented or not merged.

## Code style

We use [eslint](https://eslint.org/), airbnb style-guide and custom set of rules.

Also we're using two spaces for indentation.

## Recommended VSCode extensions within the project
- ESLint
- DotENV
- Better Comments
- Rainbow Brackets
- indent-rainbow

### May the force be with you, ADS team!
