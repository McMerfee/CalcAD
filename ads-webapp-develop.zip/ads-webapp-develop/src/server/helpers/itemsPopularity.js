export const sideProfilesPopularity = [
  {
    sideProfile: '119',
    popularity: '0',
  },
  {
    sideProfile: '119-v.p.',
    popularity: '1',
  },
  {
    sideProfile: '119-L',
    popularity: '2',
  },
  {
    sideProfile: '207',
    popularity: '3',
  },
  {
    sideProfile: '07',
    popularity: '4',
  },
  {
    sideProfile: '120',
    popularity: '5',
  },
  {
    sideProfile: '06',
    popularity: '6',
  },
  {
    sideProfile: '117',
    popularity: '7',
  },
  {
    sideProfile: 'Slim',
    popularity: '8',
  },
  {
    sideProfile: '219',
    popularity: '9',
  },
];

export const connectingProfilesPopularity = [
  {
    connectingProfile: '03',
    popularity: '0',
  },
  {
    connectingProfile: '31',
    popularity: '1',
  },
  {
    connectingProfile: '32',
    popularity: '2',
  },
];

export const mechanismsPopularity = [
  {
    mechanism: 'сил_207_1',
    popularity: '0',
  },
  {
    mechanism: 'R-219_вт',
    popularity: '1',
  },
  {
    mechanism: 'R-219_сил',
    popularity: '2',
  },
  {
    mechanism: 'вт_1',
    popularity: '3',
  },
  {
    mechanism: 'вт_2',
    popularity: '4',
  },
  {
    mechanism: 'сил_1',
    popularity: '5',
  },
  {
    mechanism: 'сил_2',
    popularity: '6',
  },
  {
    mechanism: 'під_1',
    popularity: '7',
  },
  {
    mechanism: 'під_2',
    popularity: '8',
  },
];
